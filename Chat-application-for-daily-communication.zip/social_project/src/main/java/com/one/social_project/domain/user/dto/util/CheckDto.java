package com.one.social_project.domain.user.dto.util;

import lombok.Data;

@Data
public class CheckDto {
    private Boolean result;
}
