package com.one.social_project.domain.friend.dto;

import lombok.Data;

@Data
public class FriendshipResDto {
    private String message;
}
