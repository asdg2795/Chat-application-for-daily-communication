package com.one.social_project.domain.chat.constant;

public enum ChatRole {
    OWNER,
    MEMBER
}
