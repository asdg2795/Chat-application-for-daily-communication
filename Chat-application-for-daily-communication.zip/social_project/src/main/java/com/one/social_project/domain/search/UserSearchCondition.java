package com.one.social_project.domain.search;

import lombok.Data;

@Data
public class UserSearchCondition {
    private String nickname;
}
