package com.one.social_project.domain.email.dto.util;

import lombok.Data;

@Data
public class ResultDto {
    private Boolean result;
}