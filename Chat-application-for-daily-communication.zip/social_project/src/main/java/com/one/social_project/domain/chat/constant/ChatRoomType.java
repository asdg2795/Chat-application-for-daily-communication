package com.one.social_project.domain.chat.constant;

public enum ChatRoomType {
    DM, GM
}
