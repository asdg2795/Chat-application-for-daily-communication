package com.one.social_project.domain.user.dto.register;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class RegisterResDto {
    private String message;
}
