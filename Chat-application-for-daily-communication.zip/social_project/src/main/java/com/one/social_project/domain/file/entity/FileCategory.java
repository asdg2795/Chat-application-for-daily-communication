package com.one.social_project.domain.file.entity;

public enum FileCategory {
    PROFILE, CHAT
}
