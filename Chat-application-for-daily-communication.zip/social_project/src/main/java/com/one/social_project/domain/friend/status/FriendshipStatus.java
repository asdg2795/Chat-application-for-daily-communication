package com.one.social_project.domain.friend.status;

public enum FriendshipStatus {
    ACCEPT, WAITING
}