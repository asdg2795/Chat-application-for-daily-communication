package com.one.social_project.domain.file.dto;
import lombok.*;
import lombok.experimental.SuperBuilder;

@Getter
@Setter
@SuperBuilder
@AllArgsConstructor
//@NoArgsConstructor
@ToString
public class ProfileFileDTO extends FileDTO {


//    @Enumerated(EnumType.STRING)
//    @Builder.Default
//    private FileCategory category = FileCategory.PROFILE; // 기본값 설정



}
